
import json, os, io, base64, datetime
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

# -----------------------------
# THEME & BRAND
# -----------------------------
st.set_page_config(page_title="BookYourCampus — Unified Career Assessment", page_icon="🎓", layout="wide")
PRIMARY = "#c62828"   # BYC red (placeholder); adjust to your brand palette
ACCENT = "#0d47a1"    # Deep blue accent

def byc_header():
    col1, col2 = st.columns([1,4])
    with col1:
        st.image("assets/logo.png", use_column_width=True)
    with col2:
        st.markdown(f"<h2 style='margin-bottom:0;color:{ACCENT}'>Unified Career Assessment</h2>", unsafe_allow_html=True)
        st.markdown("<p style='margin-top:0'>Interests • Personality • Learning • Skills • Values → Personalized Career Fit</p>", unsafe_allow_html=True)
    st.markdown("---")

# -----------------------------
# LOAD ITEMS & MAPPING
# -----------------------------
@st.cache_data
def load_items():
    with open("assessment/items.json","r", encoding="utf-8") as f:
        return json.load(f)

@st.cache_data
def load_mapping():
    with open("assessment/mapping.json","r", encoding="utf-8") as f:
        return json.load(f)

ITEMS = load_items()
MAPPING = load_mapping()

# -----------------------------
# HELPERS
# -----------------------------
def likert(label, key_prefix, n=5):
    labels = ["1 - Strongly Disagree","2 - Disagree","3 - Neutral","4 - Agree","5 - Strongly Agree"]
    return st.radio(label, list(range(1, n+1)), index=2, format_func=lambda x: labels[x-1], horizontal=True, key=key_prefix)

def like_scale(label, key_prefix, n=5):
    labels = ["1 - Dislike","2 - Slightly Dislike","3 - Neutral","4 - Like","5 - Strongly Like"]
    return st.radio(label, list(range(1, n+1)), index=2, format_func=lambda x: labels[x-1], horizontal=True, key=key_prefix)

def freq_scale(label, key_prefix, n=5):
    labels = ["1 - Rarely","2 - Occasionally","3 - Sometimes","4 - Often","5 - Very Often"]
    return st.radio(label, list(range(1, n+1)), index=2, format_func=lambda x: labels[x-1], horizontal=True, key=key_prefix)

def self_rate(label, key_prefix, n=5):
    labels = ["1 - Very Low","2 - Low","3 - Medium","4 - High","5 - Very High"]
    return st.radio(label, list(range(1, n+1)), index=2, format_func=lambda x: labels[x-1], horizontal=True, key=key_prefix)

def importance_scale(label, key_prefix, n=5):
    labels = ["1 - Not Important","2 - Slightly","3 - Moderately","4 - Very","5 - Extremely Important"]
    return st.radio(label, list(range(1, n+1)), index=2, format_func=lambda x: labels[x-1], horizontal=True, key=key_prefix)

def norm_scores(d):
    # Normalize dict values to 0..1 by dividing by max (avoid div by zero)
    if not d: return {}
    mx = max(d.values()) if max(d.values())>0 else 1
    return {k:v/mx for k,v in d.items()}

def ensure_dir(p):
    if not os.path.exists(p):
        os.makedirs(p, exist_ok=True)

# -----------------------------
# SCORING
# -----------------------------
def score_big5(responses):
    traits = {}
    for item in ITEMS["big5"]:
        raw = responses.get(item["id"], 3)
        val = 6-raw if item.get("reverse") else raw
        traits[item["trait"]] = traits.get(item["trait"], 0) + val
    return traits

def score_riasec(responses):
    d = {}
    for item in ITEMS["riasec"]:
        val = responses.get(item["id"], 3)
        d[item["domain"]] = d.get(item["domain"], 0) + val
    return d

def score_learning(responses):
    d = {}
    for item in ITEMS["learning"]:
        val = responses.get(item["id"], 3)
        d[item["modality"]] = d.get(item["modality"], 0) + val
    return d

def score_skills(responses):
    d = {}
    for item in ITEMS["skills"]:
        val = responses.get(item["id"], 3)
        d[item["skill"]] = d.get(item["skill"], 0) + val
    return d

def score_values(responses):
    d = {}
    for item in ITEMS["values"]:
        val = responses.get(item["id"], 3)
        d[item["value"]] = d.get(item["value"], 0) + val
    return d

def composite_cluster_scores(big5, ria, learn, skills, values):
    # Normalize each domain to 0..1
    big5n = norm_scores(big5)
    rian = norm_scores(ria)
    skilln = norm_scores(skills)
    valn = norm_scores(values)
    # Learning preferences are shown, not used heavily in scoring (optional rule: boost related clusters)
    learnn = norm_scores(learn)

    results = []
    for c in MAPPING["clusters"]:
        w = c["weights"]
        score = 0.0
        # RIASEC
        for k, wt in w.get("riasec", {}).items():
            score += wt * rian.get(k, 0.0)
        # Big Five
        for k, wt in w.get("big5", {}).items():
            score += wt * big5n.get(k, 0.0)
        # Skills
        for k, wt in w.get("skills", {}).items():
            score += wt * skilln.get(k, 0.0)
        # Values
        for k, wt in w.get("values", {}).items():
            score += wt * valn.get(k, 0.0)
        # Optional: minor boost for learning-style alignment
        if c["name"] in ["Design & Architecture"]:
            score += 0.05 * learnn.get("Visual", 0)
        if c["name"] in ["Hospitality & Tourism", "Entrepreneurship & Management"]:
            score += 0.05 * learnn.get("Kinesthetic", 0)
        if c["name"] in ["Media & Communication", "Law & Public Policy"]:
            score += 0.05 * learnn.get("Auditory", 0)
        if c["name"] in ["Commerce & Finance", "Social Sciences & Education"]:
            score += 0.05 * learnn.get("Read/Write", 0)

        results.append({
            "cluster": c["name"],
            "score": round(score, 4),
            "description": c["description"],
            "suggestions": c["suggestions"]
        })

    results = sorted(results, key=lambda x: x["score"], reverse=True)
    # Normalize final scores to percentage-like (0..100)
    mx = results[0]["score"] if results and results[0]["score"]>0 else 1.0
    for r in results:
        r["percent"] = int(round(100 * (r["score"] / mx)))
    return results

# -----------------------------
# REPORT (HTML)
# -----------------------------
def fig_to_base64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight")
    buf.seek(0)
    return base64.b64encode(buf.read()).decode("utf-8")

def build_bar_chart(data_dict, title):
    fig, ax = plt.subplots(figsize=(6,3.5))
    keys = list(data_dict.keys())
    vals = [data_dict[k] for k in keys]
    ax.bar(keys, vals)   # No custom colors
    ax.set_title(title)
    ax.set_xticklabels(keys, rotation=30, ha="right")
    return fig

def report_builder(student, big5, ria, learn, skills, values, clusters):
    # Build charts
    fig1 = build_bar_chart(big5, "Big Five (sum)")
    fig2 = build_bar_chart(ria, "RIASEC (sum)")
    fig3 = build_bar_chart(learn, "Learning Preferences (sum)")
    top5 = {r["cluster"]: r["percent"] for r in clusters[:5]}
    fig4 = build_bar_chart(top5, "Top Career Clusters (relative)")

    b64_1 = fig_to_base64(fig1)
    b64_2 = fig_to_base64(fig2)
    b64_3 = fig_to_base64(fig3)
    b64_4 = fig_to_base64(fig4)

    # HTML content
    today = datetime.date.today().strftime("%b %d, %Y")
    html = f"""
    <html>
    <head>
      <meta charset="utf-8" />
      <title>BYC Unified Career Assessment — Report</title>
      <style>
        body {{ font-family: Arial, sans-serif; margin: 24px; }}
        h1 {{ color: {ACCENT}; margin-bottom: 0; }}
        h2 {{ color: {PRIMARY}; }}
        .small {{ color: #666; }}
        .grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }}
        .card {{ border: 1px solid #eee; padding: 16px; border-radius: 8px; }}
        .badge {{ background: {PRIMARY}; color: #fff; padding: 2px 8px; border-radius: 12px; font-size: 12px; }}
        ul {{ margin-top: 8px; }}
      </style>
    </head>
    <body>
      <h1>BookYourCampus — Unified Career Assessment</h1>
      <p class="small">Report generated on {today}</p>
      <div class="card">
        <h2>Student</h2>
        <p><b>Name:</b> {student.get('name','-')} &nbsp; | &nbsp; <b>Class:</b> {student.get('grade','-')} &nbsp; | &nbsp; <b>School:</b> {student.get('school','-')}</p>
        <p><b>Preferred Country:</b> {student.get('country','-')} &nbsp; | &nbsp; <b>Contact:</b> {student.get('contact','-')}</p>
      </div>

      <div class="grid">
        <div class="card">
          <h2>Big Five</h2>
          <img src="data:image/png;base64,{b64_1}" style="max-width:100%" />
        </div>
        <div class="card">
          <h2>RIASEC Interests</h2>
          <img src="data:image/png;base64,{b64_2}" style="max-width:100%" />
        </div>
        <div class="card">
          <h2>Learning Preferences</h2>
          <img src="data:image/png;base64,{b64_3}" style="max-width:100%" />
        </div>
        <div class="card">
          <h2>Top Career Clusters</h2>
          <img src="data:image/png;base64,{b64_4}" style="max-width:100%" />
        </div>
      </div>

      <div class="card">
        <h2>Recommendations</h2>
        {"".join([f"<p><span class='badge'>{i+1}</span> <b>{c['cluster']}</b> — {c['percent']}% fit<br/><i>{c['description']}</i></p><ul>" + "".join([f"<li>{s}</li>" for s in c['suggestions']]) + "</ul>" for i,c in enumerate(clusters[:5])])}
      </div>

      <p class="small">
      <b>How to read:</b> Career clusters are ranked relatively based on your interests (RIASEC), personality (Big Five),
      skills & values. Learning preferences guide <b>how</b> you learn best. Use this report along with your marks, projects,
      and real‑world exposure to finalize choices.
      </p>
    </body>
    </html>
    """
    return html

# -----------------------------
# UI PAGES
# -----------------------------
def page_intro():
    byc_header()
    st.markdown(f"""
    <h3 style='color:{ACCENT}'>Welcome!</h3>
    <p>
    This assessment blends your <b>Interests</b>, <b>Personality</b>, <b>Learning Preferences</b>,
    <b>Skills</b> and <b>Values</b> to suggest matching <b>career clusters</b>. It takes ~12–15 minutes.
    </p>
    """, unsafe_allow_html=True)

    with st.form("student_info"):
        c1, c2 = st.columns(2)
        name = c1.text_input("Student name")
        grade = c1.selectbox("Class/Grade", ["8","9","10","11","12","UG - 1st year","UG - 2nd year","UG - 3rd year"])
        school = c2.text_input("School / College")
        country = c2.selectbox("Preferred study destination", ["India","USA","UK","Canada","Australia","Singapore","Europe (Other)"])
        contact = st.text_input("Contact email / phone")
        consent = st.checkbox("I agree to share my responses with BookYourCampus for guidance purposes.")
        submitted = st.form_submit_button("Save & Continue")
        if submitted and consent:
            st.session_state["student"] = {"name":name,"grade":grade,"school":school,"country":country,"contact":contact}
            st.success("Saved. Use the sidebar to continue.")
        elif submitted:
            st.warning("Please provide consent to proceed.")

def page_big5():
    byc_header()
    st.subheader("Personality — Big Five (IPIP‑style)")
    st.caption("Rate each statement. There are no right or wrong answers.")
    for itm in ITEMS["big5"]:
        key = itm["id"]
        st.session_state["responses"][key] = likert(itm["text"], key)

def page_riasec():
    byc_header()
    st.subheader("Interests — RIASEC")
    st.caption("How much do you enjoy the following activities?")
    for itm in ITEMS["riasec"]:
        key = itm["id"]
        st.session_state["responses"][key] = like_scale(itm["text"], key)

def page_learning():
    byc_header()
    st.subheader("Learning Preferences")
    st.caption("How often do you use/like the following ways of learning?")
    for itm in ITEMS["learning"]:
        key = itm["id"]
        st.session_state["responses"][key] = freq_scale(itm["text"], key)

def page_skills():
    byc_header()
    st.subheader("Skills & Self‑Ratings")
    st.caption("Rate your current comfort or interest level.")
    for itm in ITEMS["skills"]:
        key = itm["id"]
        st.session_state["responses"][key] = self_rate(itm["text"], key)

def page_values():
    byc_header()
    st.subheader("Work Values")
    st.caption("What matters to you in future work?")
    for itm in ITEMS["values"]:
        key = itm["id"]
        st.session_state["responses"][key] = importance_scale(itm["text"], key)

def page_results():
    byc_header()
    st.subheader("Your Results")
    if "student" not in st.session_state:
        st.info("Please fill Student Info on the Intro page first.")
        return
    big5 = score_big5(st.session_state["responses"])
    ria  = score_riasec(st.session_state["responses"])
    learn = score_learning(st.session_state["responses"])
    skills = score_skills(st.session_state["responses"])
    values = score_values(st.session_state["responses"])

    # Show charts
    c1, c2 = st.columns(2)
    with c1:
        fig1 = build_bar_chart(big5, "Big Five (sum)")
        st.pyplot(fig1, use_container_width=True)
    with c2:
        fig2 = build_bar_chart(ria, "RIASEC (sum)")
        st.pyplot(fig2, use_container_width=True)
    c3, c4 = st.columns(2)
    with c3:
        fig3 = build_bar_chart(learn, "Learning Preferences (sum)")
        st.pyplot(fig3, use_container_width=True)

    clusters = composite_cluster_scores(big5, ria, learn, skills, values)
    top = clusters[:5]
    with c4:
        top_dict = {r["cluster"]: r["percent"] for r in top}
        fig4 = build_bar_chart(top_dict, "Top Career Clusters (relative)")
        st.pyplot(fig4, use_container_width=True)

    # Show ranked clusters
    st.markdown("### Recommended Career Clusters")
    for i, r in enumerate(top, start=1):
        with st.expander(f"{i}. {r['cluster']} — {r['percent']}% fit"):
            st.write(r["description"])
            st.write("**Suggested next steps:**")
            for s in r["suggestions"]:
                st.write("- " + s)

    # Export report
    if st.button("Export Report (HTML → print to PDF)"):
        html = report_builder(st.session_state["student"], big5, ria, learn, skills, values, clusters)
        ensure_dir("exports")
        fname = f"exports/BYC_Assessment_Report_{st.session_state['student'].get('name','Student').replace(' ','_')}.html"
        with open(fname, "w", encoding="utf-8") as f:
            f.write(html)
        with open(fname, "rb") as f:
            b64 = base64.b64encode(f.read()).decode()
        st.download_button("Download Report", data=b64, file_name=os.path.basename(fname), mime="text/html")

    # Save response row (local CSV)
    ensure_dir("data")
    if st.button("Save my responses (CSV)"):
        row = {
            "timestamp": datetime.datetime.now().isoformat(),
            "name": st.session_state["student"]["name"],
            "grade": st.session_state["student"]["grade"],
            "school": st.session_state["student"]["school"],
            "country": st.session_state["student"]["country"],
            **{f"BIG5_{k}": v for k,v in big5.items()},
            **{f"RIASEC_{k}": v for k,v in ria.items()},
            **{f"LEARN_{k}": v for k,v in learn.items()}
        }
        df = pd.DataFrame([row])
        fp = "data/responses.csv"
        if os.path.exists(fp):
            df_old = pd.read_csv(fp)
            df_all = pd.concat([df_old, df], ignore_index=True)
            df_all.to_csv(fp, index=False)
        else:
            df.to_csv(fp, index=False)
        st.success("Saved to data/responses.csv (for demo).")

# -----------------------------
# APP ENTRY
# -----------------------------
if "responses" not in st.session_state:
    st.session_state["responses"] = {}

st.sidebar.title("Assessment Steps")
page = st.sidebar.radio("Navigate", ["Intro","Personality","Interests","Learning","Skills","Values","Results"])

if page == "Intro":
    page_intro()
elif page == "Personality":
    page_big5()
elif page == "Interests":
    page_riasec()
elif page == "Learning":
    page_learning()
elif page == "Skills":
    page_skills()
elif page == "Values":
    page_values()
else:
    page_results()
